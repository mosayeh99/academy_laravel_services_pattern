@notifyJs
<script src="{{asset('assets/dist/js/bootstrap.min.js')}}" defer></script>
@yield('scripts')
<script src="{{asset('assets/dist/js/demo.min.js')}}" defer></script>
