<?php $__env->startSection('title', 'Videos'); ?>
<?php $__env->startSection('stylesheets'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page header -->
    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-2 align-items-center">
                <div class="col d-flex">
                    <a class="page-title" href="<?php echo e(route('courses.index')); ?>">
                        الدورات التعليمية
                    </a>
                </div>
                <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'add videos', 'update videos', 'delete videos')): ?>
                <div class="col d-flex justify-content-end">
                    <div class="dropdown">
                        <button class="btn dropdown-toggle align-text-top" data-bs-toggle="dropdown"
                                aria-expanded="true">
                            خيارات
                        </button>
                        <div class="dropdown-menu dropdown-menu-end" data-popper-placement="bottom-end"
                             style="position: absolute; inset: 0 0 auto auto; margin: 0; transform: translate3d(0px, 39.2px, 0px);">
                            <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'add videos')): ?>
                            <a href="#" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#modal-add-video">
                                اضافة
                            </a>
                            <?php endif; ?>
                            <?php if($course->videos->count()): ?>
                                <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'add videos')): ?>
                                <a href="#" class="dropdown-item" data-bs-toggle="modal"
                                   data-bs-target="#modal-edit-video">
                                    تعديل
                                </a>
                                <?php endif; ?>
                                <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'delete videos')): ?>
                                <a href="#" class="dropdown-item text-danger" data-bs-toggle="modal"
                                   data-bs-target="#modal-danger">
                                    حذف
                                </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php if($course->videos->count()): ?>
        <!-- Page body -->
        <div class="page-body">
            <div class="container-xl">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="row row-cards">
                    <div class="col-12 col-lg-8">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="card-title"><?php echo e($video->name); ?></h3>
                                <div>
                                    <video controls class="w-full">
                                        <source src='<?php echo e(asset("storage/$video->path")); ?>' type="">
                                    </video>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><?php echo e($course->name); ?></h3>
                            </div>
                            <div class="list-group list-group-flush overflow-auto" style="max-height: 25rem">
                                <?php $__currentLoopData = $course->videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $videoInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="list-group-item">
                                        <div class="row align-items-center">
                                            <div class="col-auto">
                                                <a href="#">
                                                    <span class="avatar"><?php echo e($loop->iteration); ?></span>
                                                </a>
                                            </div>
                                            <div class="col text-truncate">
                                                <a href="<?php echo e(route('videos.index',[$course->id, $videoInfo->id])); ?>"
                                                   class="text-body d-block"><?php echo e($videoInfo->name); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-8">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">المناقشات</h3>
                            </div>
                            <div class="card-body">
                                <div id="faq-1" class="accordion" role="tablist" aria-multiselectable="true">
                                    <?php if($video->discussions->count()): ?>
                                        <?php $__currentLoopData = $video->discussions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discussion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="d-flex gap-2">
                                                <div class="col accordion-item">
                                                    <div class="accordion-header" role="tab">
                                                        <button class="accordion-button collapsed"
                                                                data-bs-toggle="collapse"
                                                                data-bs-target="#faq-4-<?php echo e($discussion->id); ?>"
                                                                aria-expanded="false">
                                                            <?php echo e($discussion->question); ?>

                                                        </button>
                                                    </div>
                                                    <div id="faq-4-<?php echo e($discussion->id); ?>"
                                                         class="accordion-collapse collapse" role="tabpanel"
                                                         data-bs-parent="#faq-1">
                                                        <div class="accordion-body pt-0">
                                                            <?php if($discussion->replies->count()): ?>
                                                                <?php $__currentLoopData = $discussion->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <div>
                                                                        <h4 class="mb-0"><?php echo e($reply->replyable->name); ?></h4>
                                                                        <p><?php echo e($reply->body); ?></p>
                                                                    </div>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php else: ?>
                                                                <div>
                                                                    <p>لم يتم اضافة رد لهذا السؤال بعد.</p>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'add replies', 'delete discussions')): ?>
                                                <div class="col-auto align-items-center d-flex">
                                                    <div class="dropdown">
                                                        <a href="#" class="btn-action" data-bs-toggle="dropdown"
                                                           aria-expanded="true">
                                                            <svg xmlns="http://www.w3.org/2000/svg" class="icon"
                                                                 width="24" height="24" viewBox="0 0 24 24"
                                                                 stroke-width="2" stroke="currentColor" fill="none"
                                                                 stroke-linecap="round" stroke-linejoin="round">
                                                                <path stroke="none" d="M0 0h24v24H0z"
                                                                      fill="none"></path>
                                                                <path
                                                                    d="M12 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path>
                                                                <path
                                                                    d="M12 19m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path>
                                                                <path
                                                                    d="M12 5m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path>
                                                            </svg>
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-end"
                                                             data-popper-placement="bottom-end"
                                                             style="position: absolute; inset: 0 0 auto auto; margin: 0; transform: translate3d(0px, 34.4px, 0px);">
                                                            <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'add replies')): ?>
                                                            <a href="#" class="dropdown-item"
                                                               onclick="setRepliedDiscussionId(<?php echo e($discussion->id); ?>)"
                                                               data-bs-toggle="modal"
                                                               data-bs-target="#modal-add-discussion-reply">اضف رد</a>
                                                            <?php endif; ?>

                                                            <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'delete discussions')): ?>
                                                            <a href="#" class="dropdown-item text-danger"
                                                               onclick="setDeletedDiscussionId(<?php echo e($discussion->id); ?>)"
                                                               data-bs-toggle="modal"
                                                               data-bs-target="#modal-del-discussion">حذف</a>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <div class="text-muted fs-3 text-center my-3">
                                            ليست هناك اي مناقشات لعرضها
                                        </div>
                                    <?php endif; ?>
                                    <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'add discussions')): ?>
                                    <form action="<?php echo e(route('discussions.store')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="d-flex align-items-end gap-2 mt-3">
                                            <div class="col">
                                                <textarea class="form-control" name="question" rows="3"
                                                          placeholder="اضف سؤال جديد"></textarea>
                                            </div>
                                            <input type="hidden" name="video_id" value="<?php echo e($video->id); ?>">
                                            <button type="submit" title="اضافة" class="btn-action">
                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                     class="icon icon-tabler icon-tabler-send" width="24" height="24"
                                                     viewBox="0 0 24 24" stroke-width="1" stroke="currentColor"
                                                     fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                    <path d="M10 14l11 -11"></path>
                                                    <path
                                                        d="M21 3l-6.5 18a.55 .55 0 0 1 -1 0l-3.5 -7l-7 -3.5a.55 .55 0 0 1 0 -1l18 -6.5"></path>
                                                </svg>
                                            </button>
                                        </div>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="page-body">
            <div class="container-xl">
                <div class="text-muted fs-2 text-center mt-5">
                    لم يضاف دروس لهذه الدورة بعد.
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Modal Add Video -->
    <div class="modal modal-blur fade" id="modal-add-video" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">اضافة درس جديد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('videos.store')); ?>" method="post" autocomplete="off" novalidate
                      enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">الاسم</label>
                            <input type="text" class="form-control" name="name" placeholder="اسم الدرس">
                        </div>
                        <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">
                        <div class="mb-3">
                            <label class="form-label">اضف الفيديو الخاص بالدرس</label>
                            <div class="position-relative">
                                <button class="btn p-4 text-muted w-100">اضغط لاضافة فيديو</button>
                                <input type="file" name="file"
                                       class="form-control opacity-0 p-4 position-absolute top-0">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="#" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                            الغاء
                        </a>
                        <button type="submit" class="btn btn-primary ms-auto" data-bs-dismiss="modal">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                 viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <path d="M12 5l0 14"/>
                                <path d="M5 12l14 0"/>
                            </svg>
                            اضافة
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php if($course->videos->count()): ?>
        <!-- Modal Edit Video -->
        <div class="modal modal-blur fade" id="modal-edit-video" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">تعديل الدرس</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="<?php echo e(route('videos.update', $video->id)); ?>" method="post" autocomplete="off" novalidate
                          enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label class="form-label">تعديل الاسم</label>
                                <input type="text" name="name" value="<?php echo e($video->name); ?>" class="form-control"
                                       placeholder="اسم الدرس">
                            </div>
                            <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">
                            <div class="mb-3">
                                <label class="form-label">اضف فيديو جديد لهذا الدرس</label>
                                <div class="position-relative">
                                    <button class="btn p-4 text-muted w-100">اضغط لاضافة فيديو</button>
                                    <input type="file" name="file"
                                           class="form-control opacity-0 p-4 position-absolute top-0">
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <a href="#" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                الغاء
                            </a>
                            <button type="submit" class="btn btn-primary ms-auto" data-bs-dismiss="modal">
                                تعديل
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Modal Delete Video -->
        <div class="modal modal-blur fade" id="modal-danger" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
                <div class="modal-content">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <div class="modal-status bg-danger"></div>
                    <div class="modal-body text-center py-4">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon mb-2 mx-auto text-danger icon-lg" width="24"
                             height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                             stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                            <path d="M12 9v2m0 4v.01"/>
                            <path
                                d="M5 19h14a2 2 0 0 0 1.84 -2.75l-7.1 -12.25a2 2 0 0 0 -3.5 0l-7.1 12.25a2 2 0 0 0 1.75 2.75"/>
                        </svg>
                        <h3>تأكيد حذف هذا الدرس؟</h3>
                    </div>
                    <div class="modal-footer">
                        <div class="w-100">
                            <div class="row">
                                <div class="col"><a href="#" class="btn w-100" data-bs-dismiss="modal">
                                        الغاء
                                    </a></div>
                                <div class="col">
                                    <form action="<?php echo e(route('videos.destroy', $video->id)); ?>" method="post">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger w-100" data-bs-dismiss="modal">حذف
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <!-- Modal Add Discussion Reply -->
    <div class="modal modal-blur fade" id="modal-add-discussion-reply" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">اضافة رد جديد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('discussion-replies.store')); ?>" method="post" autocomplete="off" novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <textarea type="text" class="form-control" name="reply" rows="3"
                                      placeholder="اضف ردك"></textarea>
                        </div>
                        <input type="hidden" name="discussion_id" id="add_reply_modal_discussion_id">
                    </div>
                    <div class="modal-footer">
                        <a href="#" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                            الغاء
                        </a>
                        <button type="submit" class="btn btn-primary ms-auto" data-bs-dismiss="modal">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                 viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <path d="M12 5l0 14"/>
                                <path d="M5 12l14 0"/>
                            </svg>
                            اضافة
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Modal Delete Discussion -->
    <div class="modal modal-blur fade" id="modal-del-discussion" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                <div class="modal-status bg-danger"></div>
                <div class="modal-body text-center py-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon mb-2 mx-auto text-danger icon-lg" width="24"
                         height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                         stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M12 9v2m0 4v.01"/>
                        <path
                            d="M5 19h14a2 2 0 0 0 1.84 -2.75l-7.1 -12.25a2 2 0 0 0 -3.5 0l-7.1 12.25a2 2 0 0 0 1.75 2.75"/>
                    </svg>
                    <h3>تأكيد حذف هذا السؤال؟</h3>
                </div>
                <div class="modal-footer">
                    <div class="w-100">
                        <div class="row">
                            <div class="col"><a href="#" class="btn w-100" data-bs-dismiss="modal">
                                    الغاء
                                </a></div>
                            <div class="col">
                                <form action="discussions/destroy" method="post">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="discussion_id" id="del_modal_discussion_id">
                                    <button type="submit" class="btn btn-danger w-100" data-bs-dismiss="modal">حذف
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function setRepliedDiscussionId(discussionId) {
            document.getElementById('add_reply_modal_discussion_id').value = discussionId;
        }

        function setDeletedDiscussionId(discussionId) {
            document.getElementById('del_modal_discussion_id').value = discussionId;
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelancer_jobs\Mostaql\S_Academy\resources\views/course_videos.blade.php ENDPATH**/ ?>