<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('stylesheets'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-body my-auto">
        <div class="container-xl">
            <div class="row row-cards mt-0">
                <div class="col-md-6 col-xl-3">
                    <a class="card card-link" href="<?php echo e(route('trainingAgencies.index')); ?>">
                        <div class="card-cover card-cover-blurred text-center bg-azure">
                            <span class="avatar avatar-xl avatar-thumb rounded bg-transparent" style="background-image: url(<?php echo e(asset('assets/static/widgets-icons/training_agencies.png')); ?>)"></span>
                        </div>
                        <div class="card-body text-center">
                            <div class="card-title mb-1">التدريب التعاوني</div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-xl-3">
                    <a class="card card-link" href="<?php echo e(route('teachers.index')); ?>">
                        <div class="card-cover card-cover-blurred text-center bg-dribbble">
                            <span class="avatar avatar-xl avatar-thumb rounded bg-transparent" style="background-image: url(<?php echo e(asset('assets/static/widgets-icons/teacher.png')); ?>)"></span>
                        </div>
                        <div class="card-body text-center">
                            <div class="card-title mb-1">المعلمين</div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-xl-3">
                    <a class="card card-link" href="<?php echo e(route('courses.index')); ?>">
                        <div class="card-cover card-cover-blurred text-center bg-cyan">
                            <span class="avatar avatar-xl avatar-thumb rounded bg-transparent" style="background-image: url(<?php echo e(asset('assets/static/widgets-icons/course.png')); ?>)"></span>
                        </div>
                        <div class="card-body text-center">
                            <div class="card-title mb-1">الدورات التعليمية</div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-xl-3">
                    <a class="card card-link" href="<?php echo e(route('virtualClassrooms.index')); ?>">
                        <div class="card-cover card-cover-blurred text-center bg-info">
                            <span class="avatar avatar-xl avatar-thumb rounded bg-transparent" style="background-image: url(<?php echo e(asset('assets/static/widgets-icons/webinar.png')); ?>)"></span>
                        </div>
                        <div class="card-body text-center">
                            <div class="card-title mb-1">فصول دراسية افتراضية</div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-xl-3">
                    <a class="card card-link" href="<?php echo e(route('students.index')); ?>">
                        <div class="card-cover card-cover-blurred text-center bg-muted">
                            <span class="avatar avatar-xl avatar-thumb rounded bg-transparent" style="background-image: url(<?php echo e(asset('assets/static/widgets-icons/student.png')); ?>)"></span>
                        </div>
                        <div class="card-body text-center">
                            <div class="card-title mb-1">الطلاب</div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-xl-3">
                    <a class="card card-link" href="<?php echo e(route('discussions.index')); ?>">
                        <div class="card-cover card-cover-blurred text-center bg-primary">
                            <span class="avatar avatar-xl avatar-thumb rounded bg-transparent" style="background-image: url(<?php echo e(asset('assets/static/widgets-icons/discussion.png')); ?>)"></span>
                        </div>
                        <div class="card-body text-center">
                            <div class="card-title mb-1">المناقشات</div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-xl-3">
                    <a class="card card-link" href="<?php echo e(route('settings.index')); ?>">
                        <div class="card-cover card-cover-blurred text-center bg-azure-lt">
                            <span class="avatar avatar-xl avatar-thumb rounded bg-transparent" style="background-image: url(<?php echo e(asset('assets/static/widgets-icons/settings.png')); ?>)"></span>
                        </div>
                        <div class="card-body text-center">
                            <div class="card-title mb-1">الإعدادات</div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MohamedElsayeh\Desktop\S_Academy\resources\views/home.blade.php ENDPATH**/ ?>