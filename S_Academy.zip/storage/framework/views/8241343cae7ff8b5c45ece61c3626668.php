<?php $__env->startSection('title', 'Training Agencies'); ?>
<?php $__env->startSection('stylesheets'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div>Training Agencies page</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MohamedElsayeh\Desktop\S_Academy\resources\views/training_agencies.blade.php ENDPATH**/ ?>