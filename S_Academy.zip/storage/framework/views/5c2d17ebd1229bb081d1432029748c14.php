<?php echo notifyJs(); ?>
<script src="<?php echo e(asset('assets/dist/js/bootstrap.min.js')); ?>" defer></script>
<?php echo $__env->yieldContent('scripts'); ?>
<script src="<?php echo e(asset('assets/dist/js/demo.min.js')); ?>" defer></script>
<?php /**PATH E:\Freelancer_jobs\Mostaql\S_Academy\resources\views/layouts/scripts.blade.php ENDPATH**/ ?>