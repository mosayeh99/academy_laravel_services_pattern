<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('stylesheets'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-body my-auto">
        <div class="container-xl">
            <div class="row row-cards mt-0">
                <?php if(! \Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Teacher', 'teacher')): ?>
                <div class="col-md-6 col-xl-3">
                    <a class="card card-link" href="<?php echo e(route('trainings.index')); ?>">
                        <div class="card-cover card-cover-blurred text-center bg-azure">
                            <span class="avatar avatar-xl avatar-thumb rounded bg-transparent" style="background-image: url(<?php echo e(asset('assets/static/widgets-icons/trainings.png')); ?>)"></span>
                        </div>
                        <div class="card-body text-center">
                            <div class="card-title mb-1">التدريب التعاوني</div>
                        </div>
                    </a>
                </div>
                <?php endif; ?>

                <?php if(! \Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'TrainingAgency', 'trainingAgency')): ?>
                <div class="col-md-6 col-xl-3">
                    <a class="card card-link" href="<?php echo e(route('courses.index')); ?>">
                        <div class="card-cover card-cover-blurred text-center bg-cyan">
                            <span class="avatar avatar-xl avatar-thumb rounded bg-transparent" style="background-image: url(<?php echo e(asset('assets/static/widgets-icons/course.png')); ?>)"></span>
                        </div>
                        <div class="card-body text-center">
                            <div class="card-title mb-1">الدورات التعليمية</div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-xl-3">
                    <a class="card card-link" href="<?php echo e(route('classrooms.index')); ?>">
                        <div class="card-cover card-cover-blurred text-center bg-info">
                            <span class="avatar avatar-xl avatar-thumb rounded bg-transparent" style="background-image: url(<?php echo e(asset('assets/static/widgets-icons/webinar.png')); ?>)"></span>
                        </div>
                        <div class="card-body text-center">
                            <div class="card-title mb-1">فصول دراسية افتراضية</div>
                        </div>
                    </a>
                </div>
                <div class="col-md-6 col-xl-3">
                    <a class="card card-link" href="<?php echo e(route('articles.index')); ?>">
                        <div class="card-cover card-cover-blurred text-center bg-vimeo">
                            <span class="avatar avatar-xl avatar-thumb rounded bg-transparent" style="background-image: url(<?php echo e(asset('assets/static/widgets-icons/articles.png')); ?>)"></span>
                        </div>
                        <div class="card-body text-center">
                            <div class="card-title mb-1">المقالات</div>
                        </div>
                    </a>
                </div>
                <?php endif; ?>

                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Admin', 'admin')): ?>
                <div class="col-md-6 col-xl-3">
                    <a class="card card-link" href="<?php echo e(route('users.index')); ?>">
                        <div class="card-cover card-cover-blurred text-center bg-dribbble">
                            <span class="avatar avatar-xl avatar-thumb rounded bg-transparent" style="background-image: url(<?php echo e(asset('assets/static/widgets-icons/users.png')); ?>)"></span>
                        </div>
                        <div class="card-body text-center">
                            <div class="card-title mb-1">المستخدمين</div>
                        </div>
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelancer_jobs\Mostaql\S_Academy\resources\views/home.blade.php ENDPATH**/ ?>