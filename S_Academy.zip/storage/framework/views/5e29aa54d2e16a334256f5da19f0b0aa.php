<?php $__env->startSection('title', 'Virtual Classrooms'); ?>
<?php $__env->startSection('stylesheets'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div>Virtual Classroom page</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MohamedElsayeh\Desktop\S_Academy\resources\views/virtual_classrooms.blade.php ENDPATH**/ ?>