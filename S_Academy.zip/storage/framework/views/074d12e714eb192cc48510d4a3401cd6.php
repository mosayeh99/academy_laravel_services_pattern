<?php $__env->startSection('title', 'Teachers'); ?>
<?php $__env->startSection('stylesheets'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page header -->
    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <h2 class="page-title">
                        المستخدمين
                    </h2>
                </div>
            </div>
        </div>
    </div>
    <!-- Page body -->
    <div class="page-body">
        <div class="container-xl">
            <div class="card">
                <div class="card-header">
                    <ul class="nav nav-tabs card-header-tabs" data-bs-toggle="tabs">
                        <li class="nav-item">
                            <a href="#tabs-students" class="nav-link active" data-bs-toggle="tab">الطلاب</a>
                        </li>
                        <li class="nav-item">
                            <a href="#tabs-teachers" class="nav-link" data-bs-toggle="tab">المعلمين</a>
                        </li>
                        <li class="nav-item">
                            <a href="#tabs-agencies" class="nav-link" data-bs-toggle="tab">المدربين</a>
                        </li>
                        <li class="nav-item">
                            <a href="#tabs-admins" class="nav-link" data-bs-toggle="tab">مسؤولوا النظام</a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="tab-content">
                        <div class="tab-pane active show" id="tabs-students">
                            <div class="card">
                                <div class="table-responsive">
                                    <table class="table table-vcenter card-table table-striped">
                                        <thead>
                                        <tr>
                                            <th class="w-1">#</th>
                                            <th>الاسم</th>
                                            <th>البريد الالكتروني</th>
                                            <th>تاريخ التسجيل</th>
                                            <th class="w-1">عمليات</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Maryjo Lebarree</td>
                                            <td><a href="#" class="text-reset">mlebarree5@unc.edu</a></td>
                                            <td class="text-muted">15/10/2023</td>
                                            <td>
                                                <a href="#">Edit</a>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="tabs-teachers">
                            <div class="card">
                                <div class="table-responsive">
                                    <table class="table table-vcenter card-table table-striped">
                                        <thead>
                                        <tr>
                                            <th class="w-1">#</th>
                                            <th>الاسم</th>
                                            <th>البريد الالكتروني</th>
                                            <th>تاريخ التسجيل</th>
                                            <th class="w-1">عمليات</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Maryjo Lebarree</td>
                                            <td><a href="#" class="text-reset">mlebarree5@unc.edu</a></td>
                                            <td class="text-muted">15/10/2023</td>
                                            <td>
                                                <a href="#">Edit</a>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="tabs-agencies">
                            <div class="card">
                                <div class="table-responsive">
                                    <table class="table table-vcenter card-table table-striped">
                                        <thead>
                                        <tr>
                                            <th class="w-1">#</th>
                                            <th>الاسم</th>
                                            <th>البريد الالكتروني</th>
                                            <th>تاريخ التسجيل</th>
                                            <th class="w-1">عمليات</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Maryjo Lebarree</td>
                                            <td><a href="#" class="text-reset">mlebarree5@unc.edu</a></td>
                                            <td class="text-muted">15/10/2023</td>
                                            <td>
                                                <a href="#">Edit</a>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="tabs-admins">
                            <div class="card">
                                <div class="table-responsive">
                                    <table class="table table-vcenter card-table table-striped">
                                        <thead>
                                        <tr>
                                            <th class="w-1">#</th>
                                            <th>الاسم</th>
                                            <th>البريد الالكتروني</th>
                                            <th>تاريخ التسجيل</th>
                                            <th class="w-1">عمليات</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Maryjo Lebarree</td>
                                            <td><a href="#" class="text-reset">mlebarree5@unc.edu</a></td>
                                            <td class="text-muted">15/10/2023</td>
                                            <td>
                                                <a href="#">Edit</a>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelancer_jobs\Mostaql\S_Academy\resources\views/teachers.blade.php ENDPATH**/ ?>