<?php $__env->startSection('title', 'Trainings'); ?>
<?php $__env->startSection('stylesheets'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page header -->
    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <h2 class="page-title">
                        التدريب التعاوني
                    </h2>
                </div>
                <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'add trainings')): ?>
                <div class="col-3 col-md-2 col-xl-1">
                    <a href="#" class="btn btn-outline-primary w-100" data-bs-toggle="modal"
                       data-bs-target="#modal-add-training">
                        اضافة تدريب
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Page body -->
    <div class="page-body">
        <div class="container-xl">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <ul class="nav nav-tabs card-header-tabs" data-bs-toggle="tabs">
                        <li class="nav-item">
                            <a href="#tabs-trainings" class="nav-link active" data-bs-toggle="tab">التدريبات</a>
                        </li>

                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Student', 'student')): ?>
                        <li class="nav-item">
                            <a href="#tabs-my-trainings" class="nav-link" data-bs-toggle="tab">حالة التقديم</a>
                        </li>
                        <?php endif; ?>

                        <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'list letters')): ?>
                        <li class="nav-item">
                            <a href="#tabs-applying-requests" class="nav-link" data-bs-toggle="tab">طلبات الالتحاق</a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="tab-content">
                        <div class="tab-pane active show" id="tabs-trainings">
                            <div id="faq-1" class="accordion" role="tablist" aria-multiselectable="true">
                                <?php if($trainings->count()): ?>
                                    <div class="row">
                                        <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-6 col-lg-3">
                                                <div class="card card-stacked">
                                                    <div class="card-body">
                                                        <div class="d-flex justify-content-between">
                                                            <h3 class="card-title"><?php echo e($training->name); ?></h3>
                                                            <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'update trainings', 'delete trainings')): ?>
                                                            <div class="dropdown">
                                                                <a href="#" class="btn-action" data-bs-toggle="dropdown"
                                                                   aria-expanded="true">
                                                                    <svg xmlns="http://www.w3.org/2000/svg"
                                                                         class="icon icon-tabler icon-tabler-dots"
                                                                         width="24" height="24" viewBox="0 0 24 24"
                                                                         stroke-width="1" stroke="currentColor"
                                                                         fill="none" stroke-linecap="round"
                                                                         stroke-linejoin="round">
                                                                        <path stroke="none" d="M0 0h24v24H0z"
                                                                              fill="none"></path>
                                                                        <path
                                                                            d="M5 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path>
                                                                        <path
                                                                            d="M12 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path>
                                                                        <path
                                                                            d="M19 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path>
                                                                    </svg>
                                                                </a>
                                                                <div class="dropdown-menu dropdown-menu-end"
                                                                     data-popper-placement="bottom-end"
                                                                     style="position: absolute; inset: 0 0 auto auto; margin: 0; transform: translate3d(0px, 34.4px, 0px);">
                                                                    <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'update trainings')): ?>
                                                                    <a href="#" class="dropdown-item"
                                                                       onclick="setEditTrainingValues('<?php echo e($training->id); ?>', '<?php echo e($training->name); ?>', '<?php echo e($training->description); ?>', '<?php echo e($training->time); ?>')"
                                                                       data-bs-toggle="modal"
                                                                       data-bs-target="#modal-edit-training">تعديل</a>
                                                                    <?php endif; ?>

                                                                    <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'delete trainings')): ?>
                                                                    <a href="#" class="dropdown-item text-danger"
                                                                       onclick="setDeletedTrainingId('<?php echo e($training->id); ?>')"
                                                                       data-bs-toggle="modal"
                                                                       data-bs-target="#modal-delete-training">حذف</a>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                            <?php endif; ?>
                                                        </div>
                                                        <p class="text-muted"><?php echo e($training->description); ?></p>
                                                    </div>
                                                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Student', 'student')): ?>
                                                    <div class="card-footer">
                                                        <a href="#" class="btn btn-primary"
                                                           onclick="setApplyTrainingValues('<?php echo e($training->name); ?>', '<?php echo e($training->id); ?>')"
                                                           data-bs-toggle="modal"
                                                           data-bs-target="#modal-apply-training">التقديم للتدريب</a>
                                                    </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php else: ?>
                                    <div class="text-muted text-center fs-3 my-5">لا توجد تدريبات جديدة لعرضها.</div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Student', 'student')): ?>
                        <div class="tab-pane" id="tabs-my-trainings">
                            <div id="faq-1" class="accordion" role="tablist" aria-multiselectable="true">
                                <?php if($letters->count()): ?>
                                    <div class="row row-cards">
                                        <?php $__currentLoopData = $letters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($letter->status): ?>
                                                <div class="col-md-6 col-lg-3">
                                                    <div class="card bg-success-lt">
                                                        <div class="card-body">
                                                            <div class="d-flex justify-content-between">
                                                                <h3 class="card-title d-flex align-items-center gap-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg"
                                                                         class="icon icon-tabler icon-tabler-circle-check"
                                                                         width="24" height="24" viewBox="0 0 24 24"
                                                                         stroke-width="1" stroke="currentColor"
                                                                         fill="none" stroke-linecap="round"
                                                                         stroke-linejoin="round">
                                                                        <path stroke="none" d="M0 0h24v24H0z"
                                                                              fill="none"></path>
                                                                        <path
                                                                            d="M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0"></path>
                                                                        <path d="M9 12l2 2l4 -4"></path>
                                                                    </svg>
                                                                    طلب مقبول
                                                                </h3>
                                                                <a href="#" class="text-muted"
                                                                   onclick="setDeletedLetterId('<?php echo e($letter->id); ?>')"
                                                                   role="button" title="حذف الطلب"
                                                                   data-bs-toggle="modal"
                                                                   data-bs-target="#modal-delete-letter">
                                                                    <svg xmlns="http://www.w3.org/2000/svg"
                                                                         class="icon icon-tabler icon-tabler-trash"
                                                                         width="24" height="24" viewBox="0 0 24 24"
                                                                         stroke-width="1" stroke="currentColor"
                                                                         fill="none" stroke-linecap="round"
                                                                         stroke-linejoin="round">
                                                                        <path stroke="none" d="M0 0h24v24H0z"
                                                                              fill="none"></path>
                                                                        <path d="M4 7l16 0"></path>
                                                                        <path d="M10 11l0 6"></path>
                                                                        <path d="M14 11l0 6"></path>
                                                                        <path
                                                                            d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12"></path>
                                                                        <path
                                                                            d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3"></path>
                                                                    </svg>
                                                                </a>
                                                            </div>
                                                            <p class="text-muted">
                                                                تم قبول طلب الالتحاق المقدم لدى
                                                                <span
                                                                    class="text-dark"><?php echo e($letter->training->name); ?></span>
                                                                على ان يبدأ التدريب يوم
                                                                <?php echo e(\Carbon\Carbon::parse($letter->training->time)->translatedFormat('l \الموافق j F Y \الساعة h A')); ?>

                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php elseif($letter->status === null): ?>
                                                <div class="col-md-6 col-lg-3">
                                                    <div class="card bg-warning-lt">
                                                        <div class="card-body">
                                                            <div class="d-flex justify-content-between">
                                                                <h3 class="card-title d-flex align-items-center gap-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg"
                                                                         class="icon icon-tabler icon-tabler-alert-circle"
                                                                         width="24" height="24" viewBox="0 0 24 24"
                                                                         stroke-width="1" stroke="currentColor"
                                                                         fill="none" stroke-linecap="round"
                                                                         stroke-linejoin="round">
                                                                        <path stroke="none" d="M0 0h24v24H0z"
                                                                              fill="none"></path>
                                                                        <path
                                                                            d="M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0"></path>
                                                                        <path d="M12 8v4"></path>
                                                                        <path d="M12 16h.01"></path>
                                                                    </svg>
                                                                    طلب تحت المراجعة
                                                                </h3>
                                                                <a href="#" class="text-muted"
                                                                   onclick="setDeletedLetterId('<?php echo e($letter->id); ?>')"
                                                                   role="button" title="حذف الطلب"
                                                                   data-bs-toggle="modal"
                                                                   data-bs-target="#modal-delete-letter">
                                                                    <svg xmlns="http://www.w3.org/2000/svg"
                                                                         class="icon icon-tabler icon-tabler-trash"
                                                                         width="24" height="24" viewBox="0 0 24 24"
                                                                         stroke-width="1" stroke="currentColor"
                                                                         fill="none" stroke-linecap="round"
                                                                         stroke-linejoin="round">
                                                                        <path stroke="none" d="M0 0h24v24H0z"
                                                                              fill="none"></path>
                                                                        <path d="M4 7l16 0"></path>
                                                                        <path d="M10 11l0 6"></path>
                                                                        <path d="M14 11l0 6"></path>
                                                                        <path
                                                                            d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12"></path>
                                                                        <path
                                                                            d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3"></path>
                                                                    </svg>
                                                                </a>
                                                            </div>
                                                            <p class="text-muted">
                                                                جاري مراجعة طلب الالتحاق المقدم لدى
                                                                <span
                                                                    class="text-dark"><?php echo e($letter->training->name); ?></span>
                                                                وقد تستغرق عملية المراجعة من 24 : 48 ساعة
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <div class="col-md-6 col-lg-3">
                                                    <div class="card bg-danger-lt">
                                                        <div class="card-body">
                                                            <div class="d-flex justify-content-between">
                                                                <h3 class="card-title d-flex align-items-center gap-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg"
                                                                         class="icon icon-tabler icon-tabler-circle-x"
                                                                         width="24" height="24" viewBox="0 0 24 24"
                                                                         stroke-width="1" stroke="currentColor"
                                                                         fill="none" stroke-linecap="round"
                                                                         stroke-linejoin="round">
                                                                        <path stroke="none" d="M0 0h24v24H0z"
                                                                              fill="none"></path>
                                                                        <path
                                                                            d="M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0"></path>
                                                                        <path d="M10 10l4 4m0 -4l-4 4"></path>
                                                                    </svg>
                                                                    طلب غير مقبول
                                                                </h3>
                                                                <a href="#" class="text-muted"
                                                                   onclick="setDeletedLetterId('<?php echo e($letter->id); ?>')"
                                                                   role="button" title="حذف الطلب"
                                                                   data-bs-toggle="modal"
                                                                   data-bs-target="#modal-delete-letter">
                                                                    <svg xmlns="http://www.w3.org/2000/svg"
                                                                         class="icon icon-tabler icon-tabler-trash"
                                                                         width="24" height="24" viewBox="0 0 24 24"
                                                                         stroke-width="1" stroke="currentColor"
                                                                         fill="none" stroke-linecap="round"
                                                                         stroke-linejoin="round">
                                                                        <path stroke="none" d="M0 0h24v24H0z"
                                                                              fill="none"></path>
                                                                        <path d="M4 7l16 0"></path>
                                                                        <path d="M10 11l0 6"></path>
                                                                        <path d="M14 11l0 6"></path>
                                                                        <path
                                                                            d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12"></path>
                                                                        <path
                                                                            d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3"></path>
                                                                    </svg>
                                                                </a>
                                                            </div>
                                                            <p class="text-muted">
                                                                نأسف لعدم قبول طلب الالتحاق المقدم لدى
                                                                <span
                                                                    class="text-dark"><?php echo e($letter->training->name); ?></span>
                                                                ونتمنى لكم التوفيق في الدورات القادمة.
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php else: ?>
                                    <div class="text-muted text-center fs-3 my-5">ليس لديك طلبات التحاق لعرضها.</div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'list letters')): ?>
                        <div class="tab-pane" id="tabs-applying-requests">
                            <div id="faq-1" class="accordion" role="tablist" aria-multiselectable="true">
                                <?php if($letters->count()): ?>
                                    <div class="card">
                                        <div class="table-responsive">
                                            <table class="table table-vcenter card-table table-striped">
                                                <thead>
                                                <tr>
                                                    <th class="w-1">#</th>
                                                    <th>اسم الطالب</th>
                                                    <th>التدريب</th>
                                                    <th>عن الطالب</th>
                                                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Admin', 'admin')): ?>
                                                    <th>حالة الطلب</th>
                                                    <?php endif; ?>
                                                    <th class="w-1">خيارات</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $letters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($letter->letterable->name); ?></td>
                                                        <td class="text-muted"><?php echo e($letter->training->name); ?></td>
                                                        <td class="text-muted"><?php echo e($letter->body); ?></td>
                                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Admin', 'admin')): ?>
                                                        <td>
                                                            <?php if($letter->status): ?>
                                                                <span class="badge bg-green-lt">مقبول</span>
                                                            <?php elseif($letter->status === null): ?>
                                                                <span class="badge bg-orange-lt">جاري المراجعة</span>
                                                            <?php else: ?>
                                                                <span class="badge bg-red-lt">مرفوض</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <?php endif; ?>
                                                        <td class="d-flex gap-3">
                                                            <?php if($letter->status === null): ?>
                                                                <a href="#" class="text-success"
                                                                   onclick="setAcceptLetterId('<?php echo e($letter->id); ?>')"
                                                                   title="قبول الطلب" data-bs-toggle="modal"
                                                                   data-bs-target="#modal-accept-letter">
                                                                    <svg xmlns="http://www.w3.org/2000/svg"
                                                                         class="icon icon-tabler icon-tabler-check"
                                                                         width="24" height="24" viewBox="0 0 24 24"
                                                                         stroke-width="2" stroke="currentColor"
                                                                         fill="none" stroke-linecap="round"
                                                                         stroke-linejoin="round">
                                                                        <path stroke="none" d="M0 0h24v24H0z"
                                                                              fill="none"></path>
                                                                        <path d="M5 12l5 5l10 -10"></path>
                                                                    </svg>
                                                                </a>
                                                                <a href="#" class="text-danger"
                                                                   onclick="setRefuseLetterId('<?php echo e($letter->id); ?>')"
                                                                   title="رفض الطلب" data-bs-toggle="modal"
                                                                   data-bs-target="#modal-refuse-letter">
                                                                    <svg xmlns="http://www.w3.org/2000/svg"
                                                                         class="icon icon-tabler icon-tabler-x"
                                                                         width="24" height="24" viewBox="0 0 24 24"
                                                                         stroke-width="1" stroke="currentColor"
                                                                         fill="none" stroke-linecap="round"
                                                                         stroke-linejoin="round">
                                                                        <path stroke="none" d="M0 0h24v24H0z"
                                                                              fill="none"></path>
                                                                        <path d="M18 6l-12 12"></path>
                                                                        <path d="M6 6l12 12"></path>
                                                                    </svg>
                                                                </a>
                                                            <?php endif; ?>
                                                            <a href="#" class="text-danger"
                                                               onclick="setDeletedLetterId('<?php echo e($letter->id); ?>')"
                                                               role="button" title="حذف الطلب" data-bs-toggle="modal"
                                                               data-bs-target="#modal-delete-letter">
                                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                                     class="icon icon-tabler icon-tabler-trash"
                                                                     width="24" height="24" viewBox="0 0 24 24"
                                                                     stroke-width="1" stroke="currentColor" fill="none"
                                                                     stroke-linecap="round" stroke-linejoin="round">
                                                                    <path stroke="none" d="M0 0h24v24H0z"
                                                                          fill="none"></path>
                                                                    <path d="M4 7l16 0"></path>
                                                                    <path d="M10 11l0 6"></path>
                                                                    <path d="M14 11l0 6"></path>
                                                                    <path
                                                                        d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12"></path>
                                                                    <path
                                                                        d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3"></path>
                                                                </svg>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="text-muted text-center fs-3 my-5">لا توجد طلبات التحاق جديدة</div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Add Training -->
    <div class="modal modal-blur fade" id="modal-add-training" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">اضافة تدريب جديد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('trainings.store')); ?>" method="post" autocomplete="off" novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">عنوان التدريب</label>
                            <input type="text" class="form-control" name="name" placeholder="اضف عنوان للتدريب">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">تاريخ بدأ التدريب</label>
                            <input type="datetime-local" class="form-control" name="time">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">عن التدريب</label>
                            <textarea class="form-control" name="description" rows="3"
                                      placeholder="اضف شرح للتدريب"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="#" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                            الغاء
                        </a>
                        <button type="submit" class="btn btn-primary ms-auto" data-bs-dismiss="modal">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                 viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                 stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                <path d="M12 5l0 14"/>
                                <path d="M5 12l14 0"/>
                            </svg>
                            اضافة
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Modal Edit Training -->
    <div class="modal modal-blur fade" id="modal-edit-training" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تعديل تدريب</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="trainings/update" method="post" autocomplete="off" novalidate>
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">عنوان التدريب</label>
                            <input type="text" class="form-control" id="edit_modal_training_name" name="name"
                                   placeholder="اضف عنوان للتدريب">
                        </div>
                        <input type="hidden" name="training_id" id="edit_modal_training_id">
                        <div class="mb-3">
                            <label class="form-label">تاريخ بدأ التدريب</label>
                            <input type="datetime-local" class="form-control" id="edit_modal_training_time"
                                   name="time">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">عن التدريب</label>
                            <textarea class="form-control" id="edit_modal_training_description" name="description"
                                      rows="3" placeholder="اضف شرح للتدريب"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="#" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                            الغاء
                        </a>
                        <button type="submit" class="btn btn-primary ms-auto" data-bs-dismiss="modal">
                            تعديل
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Modal Delete Training -->
    <div class="modal modal-blur fade" id="modal-delete-training" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                <div class="modal-status bg-danger"></div>
                <div class="modal-body text-center py-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon mb-2 mx-auto text-danger icon-lg" width="24"
                         height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                         stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M12 9v2m0 4v.01"/>
                        <path
                            d="M5 19h14a2 2 0 0 0 1.84 -2.75l-7.1 -12.25a2 2 0 0 0 -3.5 0l-7.1 12.25a2 2 0 0 0 1.75 2.75"/>
                    </svg>
                    <h3>تأكيد حذف هذا التدريب؟</h3>
                </div>
                <div class="modal-footer">
                    <div class="w-100">
                        <div class="row">
                            <div class="col">
                                <a href="#" class="btn w-100" data-bs-dismiss="modal">
                                    الغاء
                                </a>
                            </div>
                            <div class="col">
                                <form action="trainings/destroy" method="post">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="training_id" id="del_modal_training_id">
                                    <button type="submit" class="btn btn-danger w-100" data-bs-dismiss="modal">حذف
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Apply Training -->
    <div class="modal modal-blur fade" id="modal-apply-training" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="apply_modal_title"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('letters.store')); ?>" method="post" autocomplete="off" novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">عرف نفسك</label>
                            <textarea class="form-control" name="body" rows="3"
                                      placeholder="تحدث عن نفسك بشكل مختصر وحاول ابراز مهاراتك وابدي اسبابك لطلب الالتحاق بالتدريب."></textarea>
                        </div>
                        <input type="hidden" name="training_id" id="apply_modal_training_id">
                    </div>
                    <div class="modal-footer">
                        <a href="#" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                            الغاء
                        </a>
                        <button type="submit" class="btn btn-primary ms-auto" data-bs-dismiss="modal">
                            تقديم
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Modal Accept Letter -->
    <div class="modal modal-blur fade" id="modal-accept-letter" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                <div class="modal-status bg-success"></div>
                <div class="modal-body text-center py-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon mb-2 mx-auto text-green icon-lg" width="24"
                         height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                         stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0"/>
                        <path d="M9 12l2 2l4 -4"/>
                    </svg>
                    <h3>تأكيد قبول هذا الطلب؟</h3>
                </div>
                <div class="modal-footer">
                    <div class="w-100">
                        <div class="row">
                            <div class="col">
                                <a href="#" class="btn w-100" data-bs-dismiss="modal">
                                    الغاء
                                </a>
                            </div>
                            <div class="col">
                                <form action="<?php echo e(route('letters.accept')); ?>" method="post">
                                    <?php echo method_field('PUT'); ?>
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="letter_id" id="accept_modal_letter_id">
                                    <button href="#" class="btn btn-success w-100" data-bs-dismiss="modal">
                                        قبول
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Refuse Letter -->
    <div class="modal modal-blur fade" id="modal-refuse-letter" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                <div class="modal-status bg-danger"></div>
                <div class="modal-body text-center py-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon mb-2 mx-auto text-danger icon-lg" width="24"
                         height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                         stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M12 9v2m0 4v.01"/>
                        <path
                            d="M5 19h14a2 2 0 0 0 1.84 -2.75l-7.1 -12.25a2 2 0 0 0 -3.5 0l-7.1 12.25a2 2 0 0 0 1.75 2.75"/>
                    </svg>
                    <h3>تأكيد رفض هذا الطلب؟</h3>
                </div>
                <div class="modal-footer">
                    <div class="w-100">
                        <div class="row">
                            <div class="col">
                                <a href="#" class="btn w-100" data-bs-dismiss="modal">
                                    الغاء
                                </a>
                            </div>
                            <div class="col">
                                <form action="<?php echo e(route('letters.refuse')); ?>" method="post">
                                    <?php echo method_field('PUT'); ?>
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="letter_id" id="refuse_modal_letter_id">
                                    <button href="#" class="btn btn-danger w-100" data-bs-dismiss="modal">
                                        رفض
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Delete Letter -->
    <div class="modal modal-blur fade" id="modal-delete-letter" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                <div class="modal-status bg-danger"></div>
                <div class="modal-body text-center py-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon mb-2 mx-auto text-danger icon-lg" width="24"
                         height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                         stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                        <path d="M12 9v2m0 4v.01"/>
                        <path
                            d="M5 19h14a2 2 0 0 0 1.84 -2.75l-7.1 -12.25a2 2 0 0 0 -3.5 0l-7.1 12.25a2 2 0 0 0 1.75 2.75"/>
                    </svg>
                    <h3>تأكيد حذف هذا الطلب؟</h3>
                </div>
                <div class="modal-footer">
                    <div class="w-100">
                        <div class="row">
                            <div class="col">
                                <a href="#" class="btn w-100" data-bs-dismiss="modal">
                                    الغاء
                                </a>
                            </div>
                            <div class="col">
                                <form action="<?php echo e(route('letters.destroy')); ?>" method="post">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="letter_id" id="del_modal_letter_id">
                                    <button type="submit" class="btn btn-danger w-100" data-bs-dismiss="modal">حذف
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function setEditTrainingValues(trainingId, trainingName, trainingDescription, trainingTime) {
            document.getElementById('edit_modal_training_id').value = trainingId;
            document.getElementById('edit_modal_training_name').value = trainingName;
            document.getElementById('edit_modal_training_description').value = trainingDescription;
            document.getElementById('edit_modal_training_time').value = trainingTime;
        }

        function setDeletedTrainingId(trainingId) {
            document.getElementById('del_modal_training_id').value = trainingId;
        }

        function setApplyTrainingValues(modalTitle, trainingId) {
            document.getElementById('apply_modal_title').textContent = `تقديم طلب التحاق لدى ${modalTitle}`;
            document.getElementById('apply_modal_training_id').value = trainingId;
        }

        function setAcceptLetterId(letterId) {
            document.getElementById('accept_modal_letter_id').value = letterId;
        }

        function setRefuseLetterId(letterId) {
            document.getElementById('refuse_modal_letter_id').value = letterId;
        }

        function setDeletedLetterId(letterId) {
            document.getElementById('del_modal_letter_id').value = letterId;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelancer_jobs\Mostaql\S_Academy\resources\views/trainings.blade.php ENDPATH**/ ?>