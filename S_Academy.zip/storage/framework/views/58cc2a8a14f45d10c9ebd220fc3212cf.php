<?php $__env->startSection('title', 'Discussions'); ?>
<?php $__env->startSection('stylesheets'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page header -->
    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <h2 class="page-title">
                        المناقشات
                    </h2>
                </div>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Student', 'student')): ?>
                <div class="col-3 col-md-2 col-xl-1">
                    <a href="#" class="btn btn-outline-primary w-100" data-bs-toggle="modal" data-bs-target="#modal-add-discussion">
                        اضافة سؤال
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Page body -->
    <div class="page-body">
        <div class="container-xl">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="card">
                  <div class="card-header">
                      <ul class="nav nav-tabs card-header-tabs" data-bs-toggle="tabs">
                          <?php if(! \Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Admin', 'admin')): ?>
                              <li class="nav-item">
                                  <a href="#tabs-my-discussions" class="nav-link active" data-bs-toggle="tab">مناقشاتي</a>
                              </li>
                          <?php endif; ?>
                          <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Teacher', 'teacher')): ?>
                          <li class="nav-item">
                              <a href="#tabs-discussions-need-reply" class="nav-link" data-bs-toggle="tab">مناقشات لم يتم الرد عليها</a>
                          </li>
                          <?php endif; ?>
                          <li class="nav-item">
                              <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Admin', 'admin')): ?>
                              <a href="#tabs-all-discussions" class="nav-link active" data-bs-toggle="tab">جميع المناقاشات</a>
                               <?php else: ?>
                              <a href="#tabs-all-discussions" class="nav-link" data-bs-toggle="tab">جميع المناقاشات</a>
                              <?php endif; ?>
                          </li>
                      </ul>
                  </div>
                  <div class="card-body">
                      <div class="tab-content">
                          <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Student', 'student')): ?>
                          <div class="tab-pane active show" id="tabs-my-discussions">
                              <div id="faq-1" class="accordion" role="tablist" aria-multiselectable="true">
                                  <?php if($userDiscussions->count()): ?>
                                      <?php $__currentLoopData = $userDiscussions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discussion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <div class="row">
                                              <div class="col accordion-item">
                                                  <div class="accordion-header" role="tab">
                                                      <button class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#faq-1-<?php echo e($discussion->id); ?>" aria-expanded="false">
                                                          <?php echo e($discussion->question); ?>

                                                      </button>
                                                  </div>
                                                  <div id="faq-1-<?php echo e($discussion->id); ?>" class="accordion-collapse collapse" role="tabpanel" data-bs-parent="#faq-1">
                                                      <div class="accordion-body pt-0">
                                                          <?php if($discussion->replies->count()): ?>
                                                            <?php $__currentLoopData = $discussion->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                              <?php if($reply->teacher): ?>
                                                                  <div>
                                                                      <h4 class="mb-0"><?php echo e($reply->teacher->name); ?></h4>
                                                                      <p><?php echo e($reply->body); ?></p>
                                                                  </div>
                                                              <?php else: ?>
                                                                  <div>
                                                                      <h4 class="mb-0"><?php echo e($discussion->student->name); ?></h4>
                                                                      <p><?php echo e($reply->body); ?></p>
                                                                  </div>
                                                              <?php endif; ?>
                                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                          <?php else: ?>
                                                              <div>
                                                                  <p>لم يتم اضافة رد لهذا السؤال بعد.</p>
                                                              </div>
                                                          <?php endif; ?>
                                                      </div>
                                                  </div>
                                              </div>
                                              <div class="col-auto align-items-center d-flex">
                                                  <div class="dropdown">
                                                      <a href="#" class="btn-action" data-bs-toggle="dropdown" aria-expanded="true">
                                                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M12 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path><path d="M12 19m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path><path d="M12 5m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path></svg>
                                                      </a>
                                                      <div class="dropdown-menu dropdown-menu-end" data-popper-placement="bottom-end" style="position: absolute; inset: 0 0 auto auto; margin: 0; transform: translate3d(0px, 34.4px, 0px);">
                                                          <a href="#" class="dropdown-item" onclick="setRepliedDiscussionId(<?php echo e($discussion->id); ?>)" data-bs-toggle="modal" data-bs-target="#modal-add-discussion-reply">اضف رد</a>
                                                          <a href="#" class="dropdown-item text-danger" onclick="setDeletedDiscussionId(<?php echo e($discussion->id); ?>)"  data-bs-toggle="modal" data-bs-target="#modal-danger">حذف</a>
                                                      </div>
                                                  </div>
                                              </div>
                                          </div>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php else: ?>
                                      <div class="text-muted fs-3 text-center">
                                          ليس لديك اي مناقشات لعرضها
                                      </div>
                                  <?php endif; ?>
                              </div>
                          </div>
                          <?php endif; ?>

                          <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Teacher', 'teacher')): ?>
                          <div class="tab-pane active show" id="tabs-my-discussions">
                              <div id="faq-1" class="accordion" role="tablist" aria-multiselectable="true">
                                  <?php if($teacherDiscussions->count()): ?>
                                      <?php $__currentLoopData = $teacherDiscussions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discussion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <div class="row">
                                              <div class="col accordion-item">
                                                  <div class="accordion-header" role="tab">
                                                      <button class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#faq-2-<?php echo e($discussion->id); ?>" aria-expanded="false">
                                                          <?php echo e($discussion->question); ?>

                                                      </button>
                                                  </div>
                                                  <div id="faq-2-<?php echo e($discussion->id); ?>" class="accordion-collapse collapse" role="tabpanel" data-bs-parent="#faq-1">
                                                      <div class="accordion-body pt-0">
                                                          <?php $__currentLoopData = $discussion->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                  <?php if($reply->teacher): ?>
                                                                      <div>
                                                                          <h4 class="mb-0"><?php echo e($reply->teacher->name); ?></h4>
                                                                          <p><?php echo e($reply->body); ?></p>
                                                                      </div>
                                                                  <?php else: ?>
                                                                      <div>
                                                                          <h4 class="mb-0"><?php echo e($discussion->student->name); ?></h4>
                                                                          <p><?php echo e($reply->body); ?></p>
                                                                      </div>
                                                                  <?php endif; ?>
                                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                      </div>
                                                  </div>
                                              </div>
                                              <div class="col-auto align-items-center d-flex">
                                                  <div class="dropdown">
                                                      <a href="#" class="btn-action" data-bs-toggle="dropdown" aria-expanded="true">
                                                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M12 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path><path d="M12 19m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path><path d="M12 5m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path></svg>
                                                      </a>
                                                      <div class="dropdown-menu dropdown-menu-end" data-popper-placement="bottom-end" style="position: absolute; inset: 0 0 auto auto; margin: 0; transform: translate3d(0px, 34.4px, 0px);">
                                                          <a href="#" class="dropdown-item" onclick="setRepliedDiscussionId(<?php echo e($discussion->id); ?>)" data-bs-toggle="modal" data-bs-target="#modal-add-discussion-reply">اضف رد</a>
                                                          <a href="#" class="dropdown-item text-danger" onclick="setDeletedDiscussionId(<?php echo e($discussion->id); ?>)"  data-bs-toggle="modal" data-bs-target="#modal-danger">حذف</a>
                                                      </div>
                                                  </div>
                                              </div>
                                          </div>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php else: ?>
                                      <div class="text-muted fs-3 text-center">
                                          ليس لديك اي مناقشات لعرضها
                                      </div>
                                  <?php endif; ?>
                              </div>
                          </div>
                          <div class="tab-pane" id="tabs-discussions-need-reply">
                              <div id="faq-1" class="accordion" role="tablist" aria-multiselectable="true">
                                  <?php if($discussionsNeedReply->count()): ?>
                                      <?php $__currentLoopData = $discussionsNeedReply; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discussion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <div class="row">
                                              <div class="col accordion-item">
                                                  <div class="accordion-header" role="tab">
                                                      <button class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#faq-3-<?php echo e($discussion->id); ?>" aria-expanded="false">
                                                          <?php echo e($discussion->question); ?>

                                                      </button>
                                                  </div>
                                                  <div id="faq-3-<?php echo e($discussion->id); ?>" class="accordion-collapse collapse" role="tabpanel" data-bs-parent="#faq-1">
                                                      <div class="accordion-body pt-0">
                                                          <?php if($discussion->replies->count()): ?>
                                                              <?php $__currentLoopData = $discussion->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                  <?php if($reply->teacher): ?>
                                                                      <div>
                                                                          <h4 class="mb-0"><?php echo e($reply->teacher->name); ?></h4>
                                                                          <p><?php echo e($reply->body); ?></p>
                                                                      </div>
                                                                  <?php else: ?>
                                                                      <div>
                                                                          <h4 class="mb-0"><?php echo e($discussion->student->name); ?></h4>
                                                                          <p><?php echo e($reply->body); ?></p>
                                                                      </div>
                                                                  <?php endif; ?>
                                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                          <?php else: ?>
                                                              <div>
                                                                  <p>لم يتم اضافة رد لهذا السؤال بعد.</p>
                                                              </div>
                                                          <?php endif; ?>
                                                      </div>
                                                  </div>
                                              </div>
                                              <div class="col-auto align-items-center d-flex">
                                                  <div class="dropdown">
                                                      <a href="#" class="btn-action" data-bs-toggle="dropdown" aria-expanded="true">
                                                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M12 12m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path><path d="M12 19m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path><path d="M12 5m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"></path></svg>
                                                      </a>
                                                      <div class="dropdown-menu dropdown-menu-end" data-popper-placement="bottom-end" style="position: absolute; inset: 0 0 auto auto; margin: 0; transform: translate3d(0px, 34.4px, 0px);">
                                                          <a href="#" class="dropdown-item" onclick="setRepliedDiscussionId(<?php echo e($discussion->id); ?>)" data-bs-toggle="modal" data-bs-target="#modal-add-discussion-reply">اضف رد</a>
                                                          <a href="#" class="dropdown-item text-danger" onclick="setDeletedDiscussionId(<?php echo e($discussion->id); ?>)"  data-bs-toggle="modal" data-bs-target="#modal-danger">حذف</a>
                                                      </div>
                                                  </div>
                                              </div>
                                          </div>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php else: ?>
                                      <div class="text-muted fs-3 text-center">
                                          لا يوجد مناقشات جديدة للرد عليها
                                      </div>
                                  <?php endif; ?>
                              </div>
                          </div>
                          <?php endif; ?>

                          <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Admin', 'admin')): ?>
                          <div class="tab-pane active show" id="tabs-all-discussions">
                          <?php else: ?>
                          <div class="tab-pane" id="tabs-all-discussions">
                          <?php endif; ?>
                              <div id="faq-1" class="accordion" role="tablist" aria-multiselectable="true">
                                  <?php if($allDiscussions->count()): ?>
                                      <?php $__currentLoopData = $allDiscussions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discussion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <div class="col accordion-item">
                                                  <div class="accordion-header" role="tab">
                                                      <button class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#faq-4-<?php echo e($discussion->id); ?>" aria-expanded="false">
                                                          <?php echo e($discussion->question); ?>

                                                      </button>
                                                  </div>
                                                  <div id="faq-4-<?php echo e($discussion->id); ?>" class="accordion-collapse collapse" role="tabpanel" data-bs-parent="#faq-1">
                                                      <div class="accordion-body pt-0">
                                                          <?php if($discussion->replies->count()): ?>
                                                              <?php $__currentLoopData = $discussion->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                  <?php if($reply->teacher): ?>
                                                                      <div>
                                                                          <h4 class="mb-0"><?php echo e($reply->teacher->name); ?></h4>
                                                                          <p><?php echo e($reply->body); ?></p>
                                                                      </div>
                                                                  <?php else: ?>
                                                                      <div>
                                                                          <h4 class="mb-0"><?php echo e($discussion->student->name); ?></h4>
                                                                          <p><?php echo e($reply->body); ?></p>
                                                                      </div>
                                                                  <?php endif; ?>
                                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                          <?php else: ?>
                                                              <div>
                                                                  <p>لم يتم اضافة رد لهذا السؤال بعد.</p>
                                                              </div>
                                                          <?php endif; ?>
                                                      </div>
                                                  </div>
                                              </div>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php else: ?>
                                      <div class="text-muted fs-3 text-center">
                                          ليست هناك اي مناقشات لعرضها
                                      </div>
                                  <?php endif; ?>
                              </div>
                          </div>
                      </div>
                  </div>
            </div>
        </div>
    </div>

    <!-- Modal Add Discussion -->
    <div class="modal modal-blur fade" id="modal-add-discussion" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">اضافة سؤال جديد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('discussions.store')); ?>" method="post" autocomplete="off" novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">السؤال</label>
                            <textarea type="text" class="form-control" name="question" rows="3" placeholder="اضف سؤالك"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="#" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                            الغاء
                        </a>
                        <button type="submit" class="btn btn-primary ms-auto" data-bs-dismiss="modal">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 5l0 14" /><path d="M5 12l14 0" /></svg>
                            اضافة
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Modal Add Discussion Reply -->
    <div class="modal modal-blur fade" id="modal-add-discussion-reply" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">اضافة رد جديد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('discussion-replies.store')); ?>" method="post" autocomplete="off" novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">الرد</label>
                            <textarea type="text" class="form-control" name="reply" rows="3" placeholder="اضف ردك"></textarea>
                        </div>
                        <input type="hidden" name="discussion_id" id="add_reply_modal_discussion_id">
                    </div>
                    <div class="modal-footer">
                        <a href="#" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                            الغاء
                        </a>
                        <button type="submit" class="btn btn-primary ms-auto" data-bs-dismiss="modal">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 5l0 14" /><path d="M5 12l14 0" /></svg>
                            اضافة
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Modal Delete Discussion -->
    <div class="modal modal-blur fade" id="modal-danger" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                <div class="modal-status bg-danger"></div>
                <div class="modal-body text-center py-4">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon mb-2 mx-auto text-danger icon-lg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 9v2m0 4v.01" /><path d="M5 19h14a2 2 0 0 0 1.84 -2.75l-7.1 -12.25a2 2 0 0 0 -3.5 0l-7.1 12.25a2 2 0 0 0 1.75 2.75" /></svg>
                    <h3>تأكيد حذف هذا السؤال؟</h3>
                </div>
                <div class="modal-footer">
                    <div class="w-100">
                        <div class="row">
                            <div class="col"><a href="#" class="btn w-100" data-bs-dismiss="modal">
                                    الغاء
                                </a></div>
                            <div class="col">
                                <form action="discussions/destroy" method="post">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="discussion_id" id="del_modal_discussion_id">
                                    <button type="submit" class="btn btn-danger w-100" data-bs-dismiss="modal">حذف</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function setRepliedDiscussionId(discussionId){
            document.getElementById('add_reply_modal_discussion_id').value = discussionId;
        }

        function setDeletedDiscussionId(discussionId){
            document.getElementById('del_modal_discussion_id').value = discussionId;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelancer_jobs\Mostaql\S_Academy\resources\views/discussions.blade.php ENDPATH**/ ?>