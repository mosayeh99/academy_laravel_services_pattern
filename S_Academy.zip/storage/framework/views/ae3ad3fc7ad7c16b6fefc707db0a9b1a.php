<?php $__env->startSection('title', 'Page Not Found'); ?>

<?php $__env->startSection('content'); ?>
    <img src="<?php echo e(asset('assets/static/errors/404.png')); ?>">
    <p class="text-center fs-1">الصفحة التي ترغب بزيارتها غير متوفرة</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Freelancer_jobs\Mostaql\S_Academy\resources\views/errors/404.blade.php ENDPATH**/ ?>